template("tbox.console")
    add_configfiles("xmake.lua")
    add_configfiles("src/xmake.lua")

