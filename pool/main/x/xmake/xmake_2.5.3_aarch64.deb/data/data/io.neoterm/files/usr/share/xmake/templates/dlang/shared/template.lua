template("shared")
    add_configfiles("xmake.lua")
