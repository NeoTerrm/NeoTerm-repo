template("xmake.cli")
    add_configfiles("src/lni/main.c")
    add_configfiles("xmake.lua")
