更加傻瓜的脚本: 1 复制, 2 粘贴, 3 回车. 但仍建议阅读官方文档.

-   一键脚本: https://brook-community.github.io/script/
