![logo](https://storage.googleapis.com/txthinking/_/brook.png)

# Brook

> Brook is a cross-platform strong encryption and not detectable proxy.<br/>
> Brook's goal is to keep it **simple**, **stupid** and **not detectable**.<br/>
<br/>
[🇨🇳中文](https://txthinking.github.io/brook/#/zh-cn/)

[GitHub](https://github.com/txthinking/brook)
[Get Started](#cli-and-gui)

![color](#ffffff)
