## $ brook socks5tohttp

$ brook socks5tohttp 可以将 socks5 proxy 转换为 http proxy. 假设你要将 socks5 proxy `127.0.0.1:1080` 转换为 http proxy `127.0.0.1:8010`

## 运行 brook socks5tohttp

```
$ brook socks5tohttp --socks5 127.0.0.1:1080 --listen 127.0.0.1:8010
```

> 更多参数: $ brook socks5tohttp -h
