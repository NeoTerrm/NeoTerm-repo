GUI(图形用户界面), Brook 图形客户端.

## macOS

[Brook.dmg](https://github.com/txthinking/brook/releases/download/v20210401/Brook.dmg)

[BrookLite.dmg](https://github.com/txthinking/brook/releases/download/v20210401/BrookLite.dmg)

-   **保持系统版本最新**

## Windows

[Brook.exe](https://github.com/txthinking/brook/releases/download/v20210401/Brook.exe)

[BrookLite.exe](https://github.com/txthinking/brook/releases/download/v20210401/BrookLite.exe)

-   **保持系统版本最新**

## Android

[Brook.apk](https://github.com/txthinking/brook/releases/download/v20210401/Brook.apk)

## iOS

[Brook on App Store](https://apps.apple.com/us/app/brook-a-cross-platform-proxy/id1216002642)

请使用非中国大陆 Apple ID 下载.

## OpenWrt

[brook_linux_xxx.ipk](/zh-cn/brook-tproxy-gui)

---

以上下载链接你也能在[releases](https://github.com/txthinking/brook/releases)页面找到
