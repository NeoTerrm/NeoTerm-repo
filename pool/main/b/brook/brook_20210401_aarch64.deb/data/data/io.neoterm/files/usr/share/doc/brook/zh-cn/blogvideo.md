* 博客: https://talks.txthinking.com
* Youtube: https://www.youtube.com/playlist?list=PLwDQR8zI95UoH5-8T4COTxwATlABbUFI5

