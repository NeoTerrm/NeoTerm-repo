## $ brook socks5tohttp

$ brook socks5tohttp can convert a socks5 to a http proxy. Assume you want to convert socks5 proxy `127.0.0.1:1080` to http proxy `127.0.0.1:8010`

## Run brook socks5tohttp

```
$ brook socks5tohttp --socks5 127.0.0.1:1080 --listen 127.0.0.1:8010
```

> More parameters: $ brook socks5tohttp -h
