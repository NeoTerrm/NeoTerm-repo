| Command/Client | Remark | Support IPv4 | Support IPv6 |
| --- | --- | --- | --- |
| $ brook server | CLI | Yes | Yes |
| $ brook servers | CLI | Yes | Yes |
| $ brook client | CLI | Yes | Yes |
| $ brook map | CLI | Yes | Yes |
| $ brook dns | CLI | Yes | Yes |
| $ brook tproxy | CLI | Yes | Yes |
| $ brook wsserver | CLI | Yes | Yes |
| $ brook wsclient | CLI | Yes | Yes |
| $ brook relay | CLI | Yes | Yes |
| $ brook relays | CLI | Yes | Yes |
| $ brook socks5 | CLI | Yes | Yes |
| $ brook socks5tohttp | CLI | Yes | Yes |
| $ brook hijackhttps | CLI | Yes | Yes |
| macOS Client | GUI | Yes | Yes |
| Windows Client | GUI | Yes | Yes |
| iOS Client | GUI | Yes | Yes |
| Android Client | GUI | Yes | Yes |
