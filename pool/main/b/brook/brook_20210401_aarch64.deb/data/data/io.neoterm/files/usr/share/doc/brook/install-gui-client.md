GUI(Graphical user interface), Brook GUI has only client function.

## macOS

[Brook.dmg](https://github.com/txthinking/brook/releases/download/v20210401/Brook.dmg)

[BrookLite.dmg](https://github.com/txthinking/brook/releases/download/v20210401/BrookLite.dmg)

-   **Keep system up to date**

## Windows

[Brook.exe](https://github.com/txthinking/brook/releases/download/v20210401/Brook.exe)

[BrookLite.exe](https://github.com/txthinking/brook/releases/download/v20210401/BrookLite.exe)

-   **Keep system up to date**

## Android

[Brook.apk](https://github.com/txthinking/brook/releases/download/v20210401/Brook.apk)

## iOS

[Brook for iOS](https://apps.apple.com/us/app/brook-a-cross-platform-proxy/id1216002642)

## OpenWrt

[brook_linux_xxx.ipk](/brook-tproxy-gui)

---

You can get the all above download links on the [releases](https://github.com/txthinking/brook/releases) page
