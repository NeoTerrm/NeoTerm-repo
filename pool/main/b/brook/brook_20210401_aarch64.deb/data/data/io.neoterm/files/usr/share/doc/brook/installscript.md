More foolish scripts: 1 copy, 2 paste, 3 enter. But it is still recommended to read the official document to make yourself clear.

-   Install script: https://brook-community.github.io/script/
