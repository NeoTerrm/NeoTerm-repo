#ifndef _CHECK_CHECK_STDINT_H
#define _CHECK_CHECK_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "check 0.15.2"
/* generated using gnu compiler Android (6454773 based on r365631c2) clang version 9.0.8 (https://android.googlesource.com/toolchain/llvm-project 98c855489587874b2a325e7a516b99d838599c6f) (based on LLVM 9.0.8svn) */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
