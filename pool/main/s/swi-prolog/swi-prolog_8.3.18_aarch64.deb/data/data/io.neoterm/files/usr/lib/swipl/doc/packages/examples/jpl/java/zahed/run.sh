#!/data/data/io.neoterm/files/usr/bin/sh

. ../env.sh

run Zahed

