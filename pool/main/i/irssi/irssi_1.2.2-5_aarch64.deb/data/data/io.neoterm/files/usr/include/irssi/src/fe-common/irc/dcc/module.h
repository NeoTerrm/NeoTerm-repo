#include "common.h"
#include "irc.h"

#define MODULE_NAME "fe-common/irc/dcc"
