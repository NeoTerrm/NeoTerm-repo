Welcome to ne, the nice editor.
-------------------------------
ne is a free (GPL'd) text editor based on the POSIX standard that runs (we
hope) on almost any UN*X machine. ne is easy to use for the beginner, but
powerful and fully configurable for the wizard, and most sparing in its
resource usage. See the manual for some highlights of ne's features.

ne is distributed under the GNU Public License (see COPYING). The
INSTALL.md file contains detailed installation instructions. The version
of this distribution of ne can be found in src/version.h.

Documentation (in the "doc" directory) is provided in the form of a
texinfo file. It can be printed as a manual using TeX and GNU's
texinfo.tex macro package, or turned into a hypertext document using GNU's
makeinfo. The directory contains several pre-compiled printable and
hypertext versions of the documentation.

If something does not work, please feel free to email us, or write
to the mailing list.


* seba (<mailto:sebastiano.vigna@unimi.it>)
* Todd (<mailto:Todd_Lewis@unc.edu>)
* <mailto:niceeditor@googlegroups.com>
