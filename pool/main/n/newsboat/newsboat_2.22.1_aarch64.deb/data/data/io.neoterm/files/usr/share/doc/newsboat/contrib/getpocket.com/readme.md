Start with simple getpocket.com integration.

This consists of two parts.

1. create-pocket-user-token.sh has to be executed once and creates an user access token (OAuth-y) which will be then stored in ~/.pocket_access_token

2. send-to-pocket.sh actually sends a link to getpocket

Have fun,
Andreas Happe <andreashappe@snikt.net>
