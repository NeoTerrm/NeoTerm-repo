#!/data/data/io.neoterm/files/usr/bin/sh
sed -n 's/^.*BEGIN KEYBASE/BEGIN KEYBASE/p' | keybase verify
