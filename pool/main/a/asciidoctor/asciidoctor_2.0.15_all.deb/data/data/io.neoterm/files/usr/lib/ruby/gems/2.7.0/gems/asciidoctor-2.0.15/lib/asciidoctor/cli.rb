# frozen_string_literal: true
require 'optparse'
require_relative 'cli/options'
require_relative 'cli/invoker'
