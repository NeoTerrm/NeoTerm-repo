-- LuaRocks configuration

rocks_trees = {
   { name = "user", root = home .. "/.luarocks" };
   { name = "system", root = "/data/data/io.neoterm/files/usr" };
}
variables = {
   LUA_DIR = "/data/data/io.neoterm/files/usr";
   LUA_INCDIR = "/data/data/io.neoterm/files/usr/include/lua5.3";
   LUA_BINDIR = "/data/data/io.neoterm/files/usr/bin";
}
