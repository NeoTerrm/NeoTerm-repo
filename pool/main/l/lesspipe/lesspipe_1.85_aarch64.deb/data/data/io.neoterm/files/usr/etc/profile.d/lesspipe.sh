export LESSOPEN='|/data/data/io.neoterm/files/usr/bin/lesspipe.sh %s'
