#
# Configuration file for using the xslt library
#
XSLT_LIBDIR="-L/data/data/io.neoterm/files/usr/lib"
XSLT_LIBS="-lxslt -L/data/data/io.neoterm/files/usr/lib -lxml2 -lz -llzma -liconv -lm "
XSLT_PRIVATE_LIBS="-lm"
XSLT_INCLUDEDIR="-I/data/data/io.neoterm/files/usr/include"
MODULE_VERSION="xslt-1.1.34"
