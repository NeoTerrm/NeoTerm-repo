html2text(1) -- HTML to text rendering aimed for E-mail
=======================================================

## Origin
This is a continuation of html2text from
[http://www.mbayer.de/html2text](http://www.mbayer.de/html2text).
This repository includes some of the patches, no longer available at the
original sources, and improvements in functionality and building.
Starting from version 2.0, the official home of `html2text` is at
[https://github.com/grobian/html2text](https://github.com/grobian/html2text).
