#!/data/data/io.neoterm/files/usr/bin/sh


while read line ; do

	echo 2,4,red,yellow,bold
	echo 6,7,green,white
	echo

done
